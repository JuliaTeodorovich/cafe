// export function createElement(
//   tagName,
//   attributes,
//   content,
//   eventHandlers,
//   parent
// ) {}

// export function createProductCard(product, buyClickHandler) {
//   createElement();
// }

// export function createCheckoutForm() {}
